const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { randomUUID } = require('node:crypto');

let supabase;
const JWT_TTL = '7d';

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function response(statusCode, payload) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(payload)
  };
}

function assertConfiguration() {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY || !process.env.JWT_SECRET) {
    throw new HttpError(503, 'Backend is not configured. Add the Supabase URL, service role key, and JWT secret.');
  }
}

function publicMember(member) {
  return {
    id: member.id,
    fullName: member.full_name,
    phone: member.phone,
    role: member.role,
    joined: member.joined
  };
}

function publicOrder(order) {
  return {
    id: order.id,
    storeId: order.store_id,
    productId: order.product_id,
    productName: order.product_name,
    storeName: order.store_name,
    price: Number(order.price),
    commission: Number(order.commission),
    customerName: order.customer_name,
    customerPhone: order.customer_phone,
    location: order.location,
    status: order.status,
    date: order.date
  };
}

function publicStore(store, ownerPhone) {
  return {
    id: store.id,
    name: store.name,
    owner: ownerPhone || '',
    verified: store.verified,
    products: (store.products || []).map(product => ({
      id: product.id,
      name: product.name,
      price: Number(product.price),
      cat: product.cat,
      img: product.img
    }))
  };
}

function userFromToken(event) {
  const authorization = event.headers?.authorization || event.headers?.Authorization || '';
  const token = authorization.replace(/^Bearer\s+/i, '');
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    throw new HttpError(401, 'Your session has expired. Please log in again.');
  }
}

function requireRole(user, ...roles) {
  if (!user || !roles.includes(user.role)) throw new HttpError(403, 'You are not allowed to perform this action.');
}

async function query(result) {
  const { data, error } = await result;
  if (error) {
    if (error.code === '23505') throw new HttpError(409, 'That phone number or store name is already in use.');
    console.error('Database request failed:', error.message);
    throw new HttpError(500, 'The server could not complete that request.');
  }
  return data;
}

async function issueSession(member) {
  const user = publicMember(member);
  const token = jwt.sign({ id: user.id, role: user.role, phone: user.phone, fullName: user.fullName }, process.env.JWT_SECRET, { expiresIn: JWT_TTL });
  return { token, user };
}

async function bootstrap(user) {
  const settings = await query(supabase.from('platform_settings').select('commission_rate').eq('id', 'main').single());
  const rawStores = await query(supabase.from('stores').select('*, products(*)').order('created_at', { ascending: false }));
  const memberRows = user?.role === 'admin'
    ? await query(supabase.from('members').select('id,full_name,phone,role,joined').order('joined', { ascending: false }))
    : [];
  const phones = new Map();
  if (user?.role === 'admin') {
    memberRows.forEach(member => phones.set(member.id, member.phone));
  } else if (user?.role === 'seller') {
    phones.set(user.id, user.phone);
  }
  const stores = rawStores.map(store => publicStore(store, phones.get(store.owner_id)));

  let rawOrders = [];
  if (user?.role === 'admin') {
    rawOrders = await query(supabase.from('orders').select('*').order('date', { ascending: false }));
  } else if (user?.role === 'buyer') {
    rawOrders = await query(supabase.from('orders').select('*').eq('buyer_id', user.id).order('date', { ascending: false }));
  } else if (user?.role === 'seller') {
    const ownStores = await query(supabase.from('stores').select('id').eq('owner_id', user.id));
    const storeIds = ownStores.map(store => store.id);
    if (storeIds.length) rawOrders = await query(supabase.from('orders').select('*').in('store_id', storeIds).order('date', { ascending: false }));
  }

  const reports = user?.role === 'admin'
    ? await query(supabase.from('reports').select('*').order('date', { ascending: false }))
    : [];
  return {
    users: memberRows.map(publicMember),
    stores,
    orders: rawOrders.map(publicOrder),
    reports: reports.map(report => ({
      id: report.id,
      buyerPhone: report.buyer_phone,
      category: report.category,
      message: report.message,
      status: report.status,
      date: report.date
    })),
    commissionRate: Number(settings.commission_rate),
    currentUser: user ? { id: user.id, fullName: user.fullName || '', phone: user.phone, role: user.role } : null
  };
}

async function uploadProductImage(dataUrl) {
  if (!dataUrl) return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500';
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) throw new HttpError(400, 'Upload a JPEG, PNG, or WebP product image.');
  const buffer = Buffer.from(match[2], 'base64');
  if (!buffer.length || buffer.length > 4 * 1024 * 1024) throw new HttpError(413, 'The optimized product image must be 4 MB or smaller.');
  const extension = match[1].split('/')[1].replace('jpeg', 'jpg');
  const filePath = `${randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from('product-images').upload(filePath, buffer, {
    contentType: match[1],
    cacheControl: '31536000',
    upsert: false
  });
  if (error) {
    console.error('Product image upload failed:', error.message);
    throw new HttpError(502, 'The image could not be saved. Check that the product-images storage bucket exists.');
  }
  return supabase.storage.from('product-images').getPublicUrl(filePath).data.publicUrl;
}

async function route(path, method, body, user) {
  if (path === '/bootstrap' && method === 'GET') return bootstrap(user);

  if (path === '/register' && method === 'POST') {
    const fullName = String(body.fullName || '').trim();
    const phone = String(body.phone || '').trim();
    const password = String(body.password || '');
    const role = body.role === 'seller' ? 'seller' : 'buyer';
    if (fullName.length < 2 || fullName.length > 120) throw new HttpError(400, 'Enter your full name.');
    if (!/^0[17]\d{8}$/.test(phone)) throw new HttpError(400, 'Enter a valid Kenyan mobile number.');
    if (password.length < 8 || password.length > 128) throw new HttpError(400, 'Password must be at least 8 characters.');
    const passwordHash = await bcrypt.hash(password, 12);
    const member = await query(supabase.from('members').insert({ full_name: fullName, phone, password_hash: passwordHash, role }).select('*').single());
    return issueSession(member);
  }

  if (path === '/login' && method === 'POST') {
    const phone = String(body.phone || '').trim();
    const member = await query(supabase.from('members').select('*').eq('phone', phone).maybeSingle());
    if (!member || !(await bcrypt.compare(String(body.password || ''), member.password_hash))) throw new HttpError(401, 'Wrong phone or password.');
    return issueSession(member);
  }

  if (path === '/admin/login' && method === 'POST') {
    const settings = await query(supabase.from('platform_settings').select('admin_code_hash').eq('id', 'main').single());
    const configuredCode = process.env.ADMIN_ACCESS_CODE;
    if (!configuredCode) throw new HttpError(503, 'Set ADMIN_ACCESS_CODE in your server environment before using admin login.');
    let valid = settings.admin_code_hash
      ? await bcrypt.compare(String(body.code || ''), settings.admin_code_hash)
      : String(body.code || '') === configuredCode;
    if (!valid) throw new HttpError(401, 'Wrong admin code.');
    if (!settings.admin_code_hash) {
      await query(supabase.from('platform_settings').update({ admin_code_hash: await bcrypt.hash(configuredCode, 12) }).eq('id', 'main'));
    }
    const token = jwt.sign({ id: 'admin', role: 'admin', phone: 'admin', fullName: 'Admin' }, process.env.JWT_SECRET, { expiresIn: JWT_TTL });
    return { token, user: { id: 'admin', fullName: 'Admin', phone: 'admin', role: 'admin' } };
  }

  if (path === '/logout' && method === 'POST') return { ok: true };

  if (path === '/order' && method === 'POST') {
    requireRole(user, 'buyer');
    const store = await query(supabase.from('stores').select('id,name,verified').eq('id', body.storeId).maybeSingle());
    if (!store || !store.verified) throw new HttpError(404, 'This store is not available for ordering.');
    const product = await query(supabase.from('products').select('*').eq('id', body.productId).eq('store_id', store.id).maybeSingle());
    if (!product) throw new HttpError(404, 'This product is no longer available.');
    const customerName = String(body.customerName || '').trim();
    const customerPhone = String(body.customerPhone || '').trim();
    const location = String(body.location || '').trim();
    if (!customerName || !/^0[17]\d{8}$/.test(customerPhone) || location.length < 20) throw new HttpError(400, 'Enter your name, valid phone number, and detailed delivery directions.');
    const settings = await query(supabase.from('platform_settings').select('commission_rate').eq('id', 'main').single());
    const price = Number(product.price);
    const order = await query(supabase.from('orders').insert({
      buyer_id: user.id,
      store_id: store.id,
      product_id: product.id,
      product_name: product.name,
      store_name: store.name,
      price,
      commission: price * Number(settings.commission_rate) / 100,
      customer_name: customerName,
      customer_phone: customerPhone,
      location
    }).select('*').single());
    return publicOrder(order);
  }

  if (path === '/reports' && method === 'POST') {
    requireRole(user, 'buyer');
    const message = String(body.message || '').trim();
    if (!message || message.length > 1000) throw new HttpError(400, 'Enter a report message of up to 1000 characters.');
    return query(supabase.from('reports').insert({ buyer_id: user.id, buyer_phone: user.phone, category: String(body.category || 'Other'), message }).select('id').single());
  }

  if (path === '/store' && method === 'POST') {
    requireRole(user, 'seller');
    const name = String(body.name || '').trim();
    if (name.length < 2 || name.length > 100) throw new HttpError(400, 'Enter a store name.');
    const store = await query(supabase.from('stores').insert({ name, owner_id: user.id }).select('*').single());
    return publicStore({ ...store, products: [] }, user.phone);
  }

  if (path === '/product' && method === 'POST') {
    requireRole(user, 'seller');
    const store = await query(supabase.from('stores').select('id').eq('id', body.storeId).eq('owner_id', user.id).maybeSingle());
    const price = Number(body.price);
    const name = String(body.name || '').trim();
    if (!store || !name || !Number.isFinite(price) || price <= 0) throw new HttpError(400, 'Enter a product name and a price greater than zero.');
    const img = await uploadProductImage(body.img);
    const product = await query(supabase.from('products').insert({ store_id: store.id, name, price, cat: String(body.cat || 'General').slice(0, 80), img }).select('*').single());
    return { id: product.id, name: product.name, price: Number(product.price), cat: product.cat, img: product.img };
  }

  const productPath = path.match(/^\/product\/([^/]+)$/);
  if (productPath && method === 'PATCH') {
    requireRole(user, 'seller');
    const price = Number(body.price);
    if (!Number.isFinite(price) || price <= 0) throw new HttpError(400, 'Enter a price greater than zero.');
    const storeIds = await storeIdsForSeller(user.id);
    if (!storeIds.length) throw new HttpError(404, 'This product could not be found in your store.');
    const product = await query(supabase.from('products').update({ price }).eq('id', productPath[1]).in('store_id', storeIds).select('*').maybeSingle());
    if (!product) throw new HttpError(404, 'This product could not be found in your store.');
    return { id: product.id, name: product.name, price: Number(product.price), cat: product.cat, img: product.img };
  }
  if (productPath && method === 'DELETE') {
    requireRole(user, 'seller');
    const storeIds = await storeIdsForSeller(user.id);
    if (!storeIds.length) throw new HttpError(404, 'This product could not be found in your store.');
    const deleted = await query(supabase.from('products').delete().eq('id', productPath[1]).in('store_id', storeIds).select('id').maybeSingle());
    if (!deleted) throw new HttpError(404, 'This product could not be found in your store.');
    return { ok: true };
  }

  const adminStorePath = path.match(/^\/admin\/store\/([^/]+)(\/verify)?$/);
  if (adminStorePath) {
    requireRole(user, 'admin');
    const storeId = adminStorePath[1];
    if (adminStorePath[2] && method === 'PATCH') {
      const store = await query(supabase.from('stores').update({ verified: true }).eq('id', storeId).select('id,name,owner_id,verified').maybeSingle());
      if (!store) throw new HttpError(404, 'Store not found.');
      const owner = await query(supabase.from('members').select('phone').eq('id', store.owner_id).single());
      return publicStore({ ...store, products: [] }, owner.phone);
    }
    if (!adminStorePath[2] && method === 'DELETE') {
      const deleted = await query(supabase.from('stores').delete().eq('id', storeId).select('id').maybeSingle());
      if (!deleted) throw new HttpError(404, 'Store not found.');
      return { ok: true };
    }
  }

  if (path === '/admin/settings' && method === 'PATCH') {
    requireRole(user, 'admin');
    const commissionRate = Number(body.commissionRate);
    if (!Number.isFinite(commissionRate) || commissionRate < 0 || commissionRate > 100) throw new HttpError(400, 'Commission must be between 0 and 100%.');
    const update = { commission_rate: commissionRate };
    if (body.adminCode) {
      const code = String(body.adminCode);
      if (code.length < 8) throw new HttpError(400, 'Admin code must be at least 8 characters.');
      update.admin_code_hash = await bcrypt.hash(code, 12);
    }
    await query(supabase.from('platform_settings').update(update).eq('id', 'main'));
    return { ok: true };
  }

  throw new HttpError(404, 'API route not found.');
}

async function storeIdsForSeller(memberId) {
  const stores = await query(supabase.from('stores').select('id').eq('owner_id', memberId));
  return stores.map(store => store.id);
}

exports.handler = async event => {
  try {
    assertConfiguration();
    if (!supabase) {
      supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
        auth: { persistSession: false, autoRefreshToken: false }
      });
    }
    const method = event.httpMethod || 'GET';
    const pathname = new URL(event.rawUrl || `http://localhost${event.path || '/'}`).pathname;
    const path = pathname.replace(/^\/(?:\.netlify\/functions\/api|api)/, '') || '/';
    const body = event.body ? JSON.parse(event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString() : event.body) : {};
    const user = userFromToken(event);
    const result = await route(path, method, body, user);
    return response(200, result);
  } catch (error) {
    const status = error instanceof HttpError ? error.status : 500;
    if (!(error instanceof HttpError)) console.error('API request failed:', error);
    return response(status, { error: error.message || 'Unexpected server error.' });
  }
};