create extension if not exists pgcrypto;

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  phone text not null unique,
  password_hash text not null,
  role text not null check (role in ('buyer', 'seller')),
  joined timestamptz not null default now()
);

create table if not exists public.stores (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  owner_id uuid not null unique references public.members(id) on delete cascade,
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  name text not null,
  price numeric(12, 2) not null check (price > 0),
  cat text not null default 'General',
  img text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid references public.members(id) on delete set null,
  store_id uuid references public.stores(id) on delete set null,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  store_name text not null,
  price numeric(12, 2) not null,
  commission numeric(12, 2) not null default 0,
  customer_name text not null,
  customer_phone text not null,
  location text not null,
  status text not null default 'Placed',
  date timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid references public.members(id) on delete set null,
  buyer_phone text not null,
  category text not null,
  message text not null,
  status text not null default 'New',
  date timestamptz not null default now()
);

create table if not exists public.platform_settings (
  id text primary key default 'main' check (id = 'main'),
  commission_rate numeric(5, 2) not null default 5 check (commission_rate between 0 and 100),
  admin_code_hash text
);

insert into public.platform_settings (id) values ('main') on conflict (id) do nothing;

alter table public.members enable row level security;
alter table public.stores enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.reports enable row level security;
alter table public.platform_settings enable row level security;

insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = excluded.public;

create index if not exists stores_owner_id_idx on public.stores(owner_id);
create index if not exists products_store_id_idx on public.products(store_id);
create index if not exists orders_buyer_id_idx on public.orders(buyer_id);
create index if not exists orders_store_id_idx on public.orders(store_id);
create index if not exists reports_buyer_id_idx on public.reports(buyer_id);