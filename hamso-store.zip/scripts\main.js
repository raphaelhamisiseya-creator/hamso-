document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contact-form');

  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const status = document.getElementById('form-status');

      if (status) {
        status.textContent = 'Sending...';
      }

      setTimeout(() => {
        if (status) {
          status.textContent = 'Thanks — your message has been received.';
        }
        form.reset();
      }, 700);
    });
  }
});
