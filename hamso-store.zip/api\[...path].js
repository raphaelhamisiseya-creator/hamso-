const { handler } = require('../netlify/functions/api.js');

module.exports = async function apiRoute(request, response) {
  const body = request.body === undefined
    ? undefined
    : typeof request.body === 'string'
      ? request.body
      : JSON.stringify(request.body);
  const event = {
    httpMethod: request.method,
    path: request.url.split('?')[0],
    rawUrl: new URL(request.url, 'http://localhost').toString(),
    headers: request.headers,
    body
  };
  const result = await handler(event);
  response.statusCode = result.statusCode;
  for (const [name, value] of Object.entries(result.headers || {})) response.setHeader(name, value);
  response.end(result.body);
};